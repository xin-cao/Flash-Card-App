package com.example.flashcardcustomlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Stack;

public class MainActivity extends AppCompatActivity {

    private static final String MyFlag = "lfa";  //this will be our trail of breadcrumbs for logging events.

    private Button GenProbBTN, SubmitBTN;
    private EditText editText;
    private TextView numTop, numBottom, Operator, Hint, topleft;

    ArrayList<Integer> results = new ArrayList<>();
    int counter = 0;
    int score = 0;
    int top;
    int bottom;
    String symbol;
    Boolean welcome = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.e(MyFlag, "onCreate was just called");

        if(welcome){
            welcomeToast();
        }
        welcome = false;

        GenProbBTN = (Button) findViewById(R.id.GenProbBTN);
        SubmitBTN = (Button) findViewById(R.id.SubmitBTN);
        editText = (EditText) findViewById(R.id.editText);
        numTop = (TextView) findViewById(R.id.numTop);
        numBottom = (TextView) findViewById(R.id.numBottom);
        Operator = (TextView) findViewById(R.id.Operator);
        Hint = (TextView) findViewById(R.id.Hint);
        topleft = (TextView) findViewById(R.id.topleft);

        GenProbBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                counter -= counter;
                score -= score;
                SubmitBTN.setText(R.string.Submit);
                results = new ArrayList<Integer>();
                generate();
            }
        });

        SubmitBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (counter < 9){
                    String userAns = editText.getText().toString();
                    if (results.get(results.size() - 1).toString().equals(userAns)) {
                        score++;
                    }
                    generate();
                    counter ++;
                    if (counter == 9){
                        SubmitBTN.setText(R.string.SubmitQuiz);
                    }
                }else if (counter == 9) {
                    showToast(score);
                    counter ++;
                    score -= score;
                }else{
                    Toast.makeText(MainActivity.this, "click on Generate 10 questions to start again", Toast.LENGTH_LONG).show();
                }

            }
        });

    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putInt("Counter", counter);
        outState.putInt("Score", score);
        outState.putIntegerArrayList("Results", results);
        outState.putInt("Top", top);
        outState.putInt("Bottom", bottom);
        outState.putString("Symbol", symbol);
        outState.putBoolean("Welcome", false);

        super.onSaveInstanceState(outState);

    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState){

        top = savedInstanceState.getInt("Top");
        bottom = savedInstanceState.getInt("Bottom");
        counter = savedInstanceState.getInt("Counter");
        score = savedInstanceState.getInt("Score");
        symbol = savedInstanceState.getString("Symbol");
        results = savedInstanceState.getIntegerArrayList("Results");
        welcome = savedInstanceState.getBoolean("Welcome");

        numTop.setText(Integer.toString(top));
        numBottom.setText(Integer.toString(bottom));
        Operator.setText(symbol);

        super.onRestoreInstanceState(savedInstanceState);
    }

    public void welcomeToast(){
        String msg = "Welcome, <user>";

        Toast toast = Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG);
        toast.show();
    }

    public void showToast(int score){
        String text = "got " + score + " out of 10";

        Toast toast = Toast.makeText(MainActivity.this, text, Toast.LENGTH_LONG);
        toast.show();

    }

    public static int randomNumber(int min, int max) {
        return min + (int) (Math.random() * ((max - min) + 1));
    }

    public static int[] checkDiv(int top) {
        Stack stack = new Stack();
        int subNum[] = new int[13];
        for (int i = 1; i < subNum.length; i++) {
            if (top % i == 0) {
                stack.push(i);
            }
        }
        int j = 0;
        while (!stack.empty()) {
            subNum[j] = (int) stack.pop();
            j++;
        }
        return subNum;
    }

    //function that selects random number for numbottom if division
    public static int bottomRand(int[] arr) {
        int len = arr.length;
        int j = 0;
        List<Integer> noZeros = new ArrayList<Integer>();
        for(int i = 0; i < len; i++) {
            if (arr[i] == 0) {
                j++;
            } else {
                noZeros.add(arr[j]);
                j++;
            }
        }
        return noZeros.get(randomNumber(0, noZeros.size() - 1));
    }


    public void generate() {
        top = (int) ((Math.random() * (144 - 10)) + 10);
        Boolean op = (Math.random() < 0.5);
        bottom = (int) (Math.random() * 12);

        numTop.setText(Integer.toString(top));

        if(op){
            symbol = "×";
            Operator.setText(R.string.Mul);
            numBottom.setText(Integer.toString(bottom));
            results.add(top * bottom);
            //Hint.setText(results.get(results.size() - 1).toString());
        }else{
            symbol = "÷";
            Operator.setText(R.string.Div);
            int bNum = bottomRand(checkDiv(top));
            numBottom.setText(Integer.toString(bNum));
            results.add(top / bNum);
            //Hint.setText(results.get(results.size() - 1).toString());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e(MyFlag, "onDestroy was just called.");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.e(MyFlag, "onRestart was just called.");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.e(MyFlag, "onPause was just called.");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.e(MyFlag, "onStop was just called.");
    }


}

